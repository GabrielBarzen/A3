package se.gabnet.A3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
