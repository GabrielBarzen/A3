package se.gabnet.A3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A3Application {

	public static void main(String[] args) {
		SpringApplication.run(A3Application.class, args);
	}

}
